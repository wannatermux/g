#pragma once

#define HTTP_SERVER "77.221.157.235"
#define HTTP_PORT 80

#define TFTP_SERVER "77.221.157.235"
